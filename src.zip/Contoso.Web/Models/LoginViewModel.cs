﻿using System.ComponentModel.DataAnnotations;

namespace Contoso.Web.Models
{
    public class LoginViewModel
    {
        [Required]
        public string Username { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        public bool RememberLogin { get; set; } = true;
    }
}