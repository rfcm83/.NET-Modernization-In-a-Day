﻿using System;

namespace Contoso.Web.Configuration
{
    public class WebAppConfiguration
    {
        public string ApiUrl { get; set; }
        public string PolicyDocumentsPath { get; set; }
        public string ApimSubscriptionKey { get; set; }
    }
}